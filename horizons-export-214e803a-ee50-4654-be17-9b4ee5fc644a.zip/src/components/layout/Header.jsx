
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Droplet as DropletIcon, BarChart3 as BarChart3Icon, AlertTriangle as AlertTriangleIcon, FolderHeart as HomeIcon, BadgeInfo as InfoIcon } from 'lucide-react';

const Header = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: "dashboard", label: "Inicio", icon: HomeIcon },
    { id: "statistics", label: "Estadísticas", icon: BarChart3Icon },
    { id: "alerts", label: "Alertas", icon: AlertTriangleIcon },
    { id: "tips", label: "Consejos", icon: InfoIcon },
  ];

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <motion.div
              initial={{ rotate: 0 }}
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              className="text-primary"
            >
              <DropletIcon size={32} />
            </motion.div>
            <h1 className="text-2xl font-bold gradient-text">AguaConsciente</h1>
          </div>
          <nav>
            <ul className="flex space-x-6">
              {navItems.map((item) => (
                <li key={item.id}>
                  <Button
                    variant={activeTab === item.id ? "default" : "ghost"}
                    onClick={() => setActiveTab(item.id)}
                    className="flex items-center gap-2"
                  >
                    <item.icon size={18} />
                    <span>{item.label}</span>
                  </Button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
