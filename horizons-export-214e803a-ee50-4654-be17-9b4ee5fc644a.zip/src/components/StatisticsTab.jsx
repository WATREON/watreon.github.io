
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { TrendingUp as TrendingUpIcon } from 'lucide-react';

const StatisticsTab = ({ data }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Estadísticas Detalladas</h2>
        <p className="text-gray-600">Análisis completo de tu consumo de agua</p>
      </div>

      <Tabs defaultValue="daily" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="daily">Consumo Diario</TabsTrigger>
          <TabsTrigger value="monthly">Consumo Mensual</TabsTrigger>
          <TabsTrigger value="comparison">Comparativa</TabsTrigger>
        </TabsList>
        
        <TabsContent value="daily" className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Consumo Diario Detallado</CardTitle>
              <CardDescription>Análisis del consumo por día de la semana</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <div className="h-full flex items-end space-x-4">
                  {data.dailyUsage.map((day, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div className="w-full flex justify-center mb-2 relative">
                        <motion.div 
                          initial={{ height: 0 }}
                          animate={{ height: `${(day.usage / 250) * 100}%` }}
                          transition={{ duration: 1, delay: index * 0.1 }}
                          className={`w-16 rounded-t-md ${
                            day.usage > data.dailyGoal * 1.2 ? 'bg-red-400' : 
                            day.usage > data.dailyGoal ? 'bg-amber-400' : 
                            'bg-blue-400'
                          }`}
                        />
                        {day.usage > data.dailyGoal && (
                          <div className="absolute -top-6 left-0 right-0 text-center">
                            <span className="text-xs font-medium px-2 py-1 rounded-full bg-red-100 text-red-800">
                              +{Math.round((day.usage / data.dailyGoal - 1) * 100)}%
                            </span>
                          </div>
                        )}
                      </div>
                      <div className="text-sm font-medium">{day.day}</div>
                      <div className="text-xs text-gray-500">{day.usage} L</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="mt-8 p-4 bg-blue-50 rounded-md border border-blue-100">
                <h4 className="font-medium text-blue-800 mb-2">Análisis de Consumo</h4>
                <ul className="space-y-2 text-sm text-blue-700">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>El consumo más alto fue el <strong>Jueves</strong> con <strong>220 litros</strong>.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>El consumo más bajo fue el <strong>Domingo</strong> con <strong>100 litros</strong>.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>El promedio semanal es de <strong>{Math.round(data.dailyUsage.reduce((acc, day) => acc + day.usage, 0) / 7)} litros</strong> por día.</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Hay <strong>{data.dailyUsage.filter(day => day.usage > data.dailyGoal).length} días</strong> que superan la meta diaria.</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="monthly" className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Consumo Mensual</CardTitle>
              <CardDescription>Análisis del consumo por mes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <div className="h-full flex items-end space-x-4">
                  {data.monthlyUsage.map((month, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div className="w-full flex justify-center mb-2">
                        <motion.div 
                          initial={{ height: 0 }}
                          animate={{ height: `${(month.usage / 4000) * 100}%` }}
                          transition={{ duration: 1, delay: index * 0.1 }}
                          className="w-16 rounded-t-md bg-blue-400 bg-opacity-80"
                        />
                      </div>
                      <div className="text-sm font-medium">{month.month}</div>
                      <div className="text-xs text-gray-500">{month.usage} L</div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-md border border-blue-100">
                  <h4 className="font-medium text-blue-800 mb-2">Tendencia de Consumo</h4>
                  <p className="text-sm text-blue-700 mb-4">
                    Se observa un incremento gradual en el consumo de agua durante los últimos meses, con un aumento del 
                    <strong> {Math.round((data.monthlyUsage[data.monthlyUsage.length-1].usage / data.monthlyUsage[0].usage - 1) * 100)}%</strong> 
                    desde {data.monthlyUsage[0].month} hasta {data.monthlyUsage[data.monthlyUsage.length-1].month}.
                  </p>
                  <div className="flex items-center">
                    <TrendingUpIcon size={20} className="text-amber-500 mr-2" />
                    <span className="text-sm font-medium text-amber-700">Tendencia al alza</span>
                  </div>
                </div>
                
                <div className="p-4 bg-green-50 rounded-md border border-green-100">
                  <h4 className="font-medium text-green-800 mb-2">Oportunidades de Ahorro</h4>
                  <ul className="space-y-2 text-sm text-green-700">
                    <li className="flex items-start">
                      <span className="mr-2">•</span>
                      <span>Revisar el sistema de riego en verano.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">•</span>
                      <span>Instalar dispositivos de ahorro en duchas.</span>
                    </li>
                    <li className="flex items-start">
                      <span className="mr-2">•</span>
                      <span>Reparar posibles fugas en tuberías.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="comparison" className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Comparativa con Promedios</CardTitle>
              <CardDescription>Tu consumo vs. el promedio nacional</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-medium mb-4">Consumo Diario por Persona</h4>
                  <div className="relative pt-8 pb-4">
                    <div className="flex items-end space-x-12">
                      <div className="flex flex-col items-center">
                        <div className="absolute top-0 left-12 transform -translate-x-1/2 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                          Tu consumo
                        </div>
                        <motion.div 
                          initial={{ height: 0 }}
                          animate={{ height: 150 }}
                          transition={{ duration: 1 }}
                          className="w-24 rounded-t-md bg-blue-400"
                        />
                        <div className="mt-2 text-center">
                          <div className="font-medium">{Math.round(data.currentUsage / 3)} L</div>
                          <div className="text-xs text-gray-500">por persona</div>
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-center">
                        <div className="absolute top-0 right-12 transform translate-x-1/2 bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium">
                          Promedio nacional
                        </div>
                        <motion.div 
                          initial={{ height: 0 }}
                          animate={{ height: 200 }}
                          transition={{ duration: 1 }}
                          className="w-24 rounded-t-md bg-gray-400"
                        />
                        <div className="mt-2 text-center">
                          <div className="font-medium">132 L</div>
                          <div className="text-xs text-gray-500">por persona</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 p-4 bg-blue-50 rounded-md border border-blue-100">
                    <h4 className="font-medium text-blue-800 mb-2">Análisis</h4>
                    <p className="text-sm text-blue-700">
                      Tu consumo por persona es un <strong>{Math.round(Math.round(data.currentUsage / 3) / 132 * 100 - 100)}%</strong> {Math.round(data.currentUsage / 3) > 132 ? 'mayor' : 'menor'} que el promedio nacional.
                    </p>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-lg font-medium mb-4">Consumo Mensual por Hogar</h4>
                  <div className="relative pt-8 pb-4">
                    <div className="flex items-end space-x-12">
                      <div className="flex flex-col items-center">
                        <div className="absolute top-0 left-12 transform -translate-x-1/2 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                          Tu hogar
                        </div>
                        <motion.div 
                          initial={{ height: 0 }}
                          animate={{ height: 180 }}
                          transition={{ duration: 1 }}
                          className="w-24 rounded-t-md bg-blue-400"
                        />
                        <div className="mt-2 text-center">
                          <div className="font-medium">{data.monthlyUsageTotal} L</div>
                          <div className="text-xs text-gray-500">por mes</div>
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-center">
                        <div className="absolute top-0 right-12 transform translate-x-1/2 bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium">
                          Promedio nacional
                        </div>
                        <motion.div 
                          initial={{ height: 0 }}
                          animate={{ height: 150 }}
                          transition={{ duration: 1 }}
                          className="w-24 rounded-t-md bg-gray-400"
                        />
                        <div className="mt-2 text-center">
                          <div className="font-medium">3500 L</div>
                          <div className="text-xs text-gray-500">por mes</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 p-4 bg-amber-50 rounded-md border border-amber-100">
                    <h4 className="font-medium text-amber-800 mb-2">Recomendación</h4>
                    <p className="text-sm text-amber-700">
                      Tu consumo mensual está un <strong>{Math.round(data.monthlyUsageTotal / 3500 * 100 - 100)}%</strong> por encima del promedio nacional. Considera implementar medidas de ahorro adicionales.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default StatisticsTab;
