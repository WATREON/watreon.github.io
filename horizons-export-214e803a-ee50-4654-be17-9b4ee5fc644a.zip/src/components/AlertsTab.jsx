
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { AlertTriangle as AlertTriangleIcon, CheckCircle as CheckCircleIcon, BadgeInfo as InfoIcon, FileImage as SaveIcon } from 'lucide-react';

const AlertsTab = ({ data, resolveAlert }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Sistema de Alertas</h2>
        <p className="text-gray-600">Monitoreo y notificaciones de consumo excesivo</p>
      </div>

      <Tabs defaultValue="active" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="active">Alertas Activas</TabsTrigger>
          <TabsTrigger value="resolved">Alertas Resueltas</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Alertas Activas</CardTitle>
              <CardDescription>Alertas que requieren atención</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data.alerts.filter(alert => alert.status === "active").map((alert, index) => (
                  <motion.div 
                    key={index}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className={`p-4 rounded-md flex justify-between items-center ${
                      alert.type === "Exceso" ? "bg-amber-50 border border-amber-200" : 
                      alert.type === "Fuga" ? "bg-red-50 border border-red-200 alert-pulse" : 
                      "bg-blue-50 border border-blue-200"
                    }`}
                  >
                    <div className="flex items-center">
                      <AlertTriangleIcon size={24} className={`mr-3 ${
                        alert.type === "Exceso" ? "text-amber-500" : 
                        alert.type === "Fuga" ? "text-red-500" : 
                        "text-blue-500"
                      }`} />
                      <div>
                        <p className="font-medium">{alert.type}</p>
                        <p className="text-sm text-gray-600">{alert.message}</p>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => resolveAlert(alert.id)}
                    >
                      Marcar como resuelto
                    </Button>
                  </motion.div>
                ))}
                {data.alerts.filter(alert => alert.status === "active").length === 0 && (
                  <div className="p-8 bg-green-50 rounded-md border border-green-200 text-center">
                    <CheckCircleIcon size={48} className="text-green-500 mx-auto mb-4" />
                    <p className="text-lg font-medium text-green-800">No hay alertas activas</p>
                    <p className="text-sm text-green-600 mt-2">Tu sistema está funcionando correctamente</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="resolved" className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Alertas Resueltas</CardTitle>
              <CardDescription>Historial de alertas resueltas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data.alerts.filter(alert => alert.status === "resolved").map((alert, index) => (
                  <motion.div 
                    key={index}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="p-4 rounded-md flex justify-between items-center bg-gray-50 border border-gray-200"
                  >
                    <div className="flex items-center">
                      <CheckCircleIcon size={24} className="text-green-500 mr-3" />
                      <div>
                        <p className="font-medium">{alert.type} (Resuelto)</p>
                        <p className="text-sm text-gray-600">{alert.message}</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                      Resuelto
                    </span>
                  </motion.div>
                ))}
                {data.alerts.filter(alert => alert.status === "resolved").length === 0 && (
                  <div className="p-8 bg-gray-50 rounded-md border border-gray-200 text-center">
                    <InfoIcon size={48} className="text-gray-400 mx-auto mb-4" />
                    <p className="text-lg font-medium text-gray-800">No hay alertas resueltas</p>
                    <p className="text-sm text-gray-600 mt-2">El historial de alertas resueltas aparecerá aquí</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings" className="space-y-6">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Configuración de Alertas</CardTitle>
              <CardDescription>Personaliza tus notificaciones y umbrales de alerta</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 rounded-md border border-gray-200">
                  <h4 className="font-medium mb-4">Umbrales de Alerta</h4>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Consumo excesivo diario</span>
                        <span className="text-sm text-blue-600">{data.dailyGoal} litros</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '75%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Detección de fugas</span>
                        <span className="text-sm text-blue-600">Sensibilidad media</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '50%' }}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm font-medium">Consumo nocturno anormal</span>
                        <span className="text-sm text-blue-600">10 litros/hora</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '30%' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="p-4 rounded-md border border-gray-200">
                  <h4 className="font-medium mb-4">Notificaciones</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Alertas por correo electrónico</span>
                      <div className="w-12 h-6 bg-blue-500 rounded-full relative cursor-pointer">
                        <div className="absolute right-1 top-1 bg-white w-4 h-4 rounded-full"></div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Alertas por SMS</span>
                      <div className="w-12 h-6 bg-gray-300 rounded-full relative cursor-pointer">
                        <div className="absolute left-1 top-1 bg-white w-4 h-4 rounded-full"></div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Notificaciones push</span>
                      <div className="w-12 h-6 bg-blue-500 rounded-full relative cursor-pointer">
                        <div className="absolute right-1 top-1 bg-white w-4 h-4 rounded-full"></div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Informes semanales</span>
                      <div className="w-12 h-6 bg-blue-500 rounded-full relative cursor-pointer">
                        <div className="absolute right-1 top-1 bg-white w-4 h-4 rounded-full"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full flex items-center gap-2">
                <SaveIcon size={16} />
                Guardar configuración
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default AlertsTab;
