
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle as AlertTriangleIcon, TrendingUp as TrendingUpIcon, TrendingDown as TrendingDownIcon, CheckCircle as CheckCircleIcon, Settings as SettingsIcon, RefreshCw as RefreshCwIcon } from 'lucide-react';

const DashboardTab = ({ data, progress, resolveAlert, addRandomUsage, updateGoal, setActiveTab }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Panel de Control</h2>
        <p className="text-gray-600">Monitoreo en tiempo real del consumo de agua</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="stat-card"
        >
          <Card className="border-l-4 border-l-primary shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Consumo Actual</CardTitle>
              <CardDescription>Consumo diario de hoy</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-end">
                <div className="text-4xl font-bold text-primary">{data.currentUsage} L</div>
                <div className="text-sm text-gray-500">Meta: {data.dailyGoal} L</div>
              </div>
              <div className="mt-4">
                <Progress value={progress} className="h-2" />
              </div>
              <div className="mt-2 text-sm flex justify-between">
                <span>0 L</span>
                <span className={data.currentUsage > data.dailyGoal ? "text-red-500" : "text-green-500"}>
                  {data.currentUsage > data.dailyGoal ? (
                    <span className="flex items-center">
                      <TrendingUpIcon size={16} className="mr-1" />
                      {Math.round((data.currentUsage / data.dailyGoal - 1) * 100)}% sobre la meta
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <TrendingDownIcon size={16} className="mr-1" />
                      {Math.round((1 - data.currentUsage / data.dailyGoal) * 100)}% bajo la meta
                    </span>
                  )}
                </span>
                <span>{data.dailyGoal * 2} L</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="stat-card"
        >
          <Card className="border-l-4 border-l-blue-400 shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Consumo Mensual</CardTitle>
              <CardDescription>Total acumulado este mes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-end">
                <div className="text-4xl font-bold text-blue-500">{data.monthlyUsageTotal} L</div>
                <div className="text-sm text-gray-500">Meta: {data.monthlyGoal} L</div>
              </div>
              <div className="mt-4">
                <Progress value={data.monthlyUsageTotal / data.monthlyGoal * 100} className="h-2 bg-blue-100" />
              </div>
              <div className="mt-2 text-sm flex justify-between">
                <span>0 L</span>
                <span className="text-blue-500">
                  {Math.round(data.monthlyUsageTotal / data.monthlyGoal * 100)}% de la meta
                </span>
                <span>{data.monthlyGoal} L</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="stat-card"
        >
          <Card className="border-l-4 border-l-green-400 shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Ahorro</CardTitle>
              <CardDescription>Comparado con el mes anterior</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-green-500">{data.savingsPercentage}%</div>
              <div className="mt-2 text-sm text-gray-500">Has ahorrado aproximadamente {Math.round(data.monthlyUsageTotal * data.savingsPercentage / 100)} litros de agua</div>
              <div className="mt-4 p-3 bg-green-50 rounded-md border border-green-100">
                <div className="flex items-start">
                  <CheckCircleIcon size={20} className="text-green-500 mr-2 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-green-800">¡Buen trabajo!</p>
                    <p className="text-xs text-green-600">Continúa con tus hábitos de ahorro de agua.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Consumo Diario (Últimos 7 días)</CardTitle>
            <CardDescription>Litros consumidos por día</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <div className="h-full flex items-end space-x-2">
                {data.dailyUsage.map((day, index) => (
                  <div key={index} className="flex-1 flex flex-col items-center">
                    <div className="w-full flex justify-center mb-2">
                      <motion.div 
                        initial={{ height: 0 }}
                        animate={{ height: `${(day.usage / 250) * 100}%` }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                        className={`w-8 rounded-t-md ${day.usage > data.dailyGoal ? 'bg-red-400' : 'bg-blue-400'}`}
                      />
                    </div>
                    <div className="text-xs font-medium">{day.day.substring(0, 3)}</div>
                    <div className="text-xs text-gray-500">{day.usage} L</div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={addRandomUsage} className="flex items-center gap-2">
              <RefreshCwIcon size={16} />
              Actualizar datos
            </Button>
            <Button variant="outline" onClick={() => updateGoal(data.dailyGoal === 150 ? 180 : 150)} className="flex items-center gap-2">
              <SettingsIcon size={16} />
              Cambiar meta ({data.dailyGoal === 150 ? '180L' : '150L'})
            </Button>
          </CardFooter>
        </Card>

        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Alertas Recientes</CardTitle>
            <CardDescription>Notificaciones sobre consumo excesivo y posibles fugas</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.alerts.filter(alert => alert.status === "active").slice(0, 3).map((alert, index) => (
                <motion.div 
                  key={index}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className={`p-4 rounded-md flex justify-between items-center ${
                    alert.type === "Exceso" ? "bg-amber-50 border border-amber-200" : 
                    alert.type === "Fuga" ? "bg-red-50 border border-red-200 alert-pulse" : 
                    "bg-blue-50 border border-blue-200"
                  }`}
                >
                  <div className="flex items-center">
                    <AlertTriangleIcon size={20} className={`mr-2 ${
                      alert.type === "Exceso" ? "text-amber-500" : 
                      alert.type === "Fuga" ? "text-red-500" : 
                      "text-blue-500"
                    }`} />
                    <div>
                      <p className="text-sm font-medium">{alert.type}</p>
                      <p className="text-xs text-gray-600">{alert.message}</p>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => resolveAlert(alert.id)}
                    className="text-xs"
                  >
                    Resolver
                  </Button>
                </motion.div>
              ))}
              {data.alerts.filter(alert => alert.status === "active").length === 0 && (
                <div className="p-4 bg-green-50 rounded-md border border-green-200 text-center">
                  <CheckCircleIcon size={24} className="text-green-500 mx-auto mb-2" />
                  <p className="text-sm font-medium text-green-800">No hay alertas activas</p>
                  <p className="text-xs text-green-600">Tu sistema está funcionando correctamente</p>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full" onClick={() => setActiveTab("alerts")}>
              Ver todas las alertas
            </Button>
          </CardFooter>
        </Card>
      </div>
    </motion.div>
  );
};

export default DashboardTab;
