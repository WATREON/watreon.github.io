
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Droplet as DropletIcon } from 'lucide-react';

const TipsTab = ({ data }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Consejos para Ahorrar Agua</h2>
        <p className="text-gray-600">Recomendaciones para reducir tu consumo de agua</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="shadow-lg border-t-4 border-t-blue-500">
          <CardHeader>
            <CardTitle>Consejos Diarios</CardTitle>
            <CardDescription>Pequeños cambios, grandes resultados</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              {data.tips.map((tip, index) => (
                <motion.li 
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="flex items-start p-3 rounded-md bg-blue-50"
                >
                  <DropletIcon size={20} className="text-blue-500 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{tip}</span>
                </motion.li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="shadow-lg border-t-4 border-t-green-500">
          <CardHeader>
            <CardTitle>Tecnologías de Ahorro</CardTitle>
            <CardDescription>Dispositivos que te ayudan a reducir el consumo</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="flex items-start p-4 rounded-md bg-green-50"
              >
                <div className="mr-4 flex-shrink-0">
                  <div className="w-16 h-16 rounded-md bg-white p-2 flex items-center justify-center shadow-sm">
                    <img  alt="Aireador de grifo" className="w-full h-full object-contain" src="https://images.unsplash.com/photo-1629269758505-efba130bafe0" />
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-green-800">Aireadores para Grifos</h4>
                  <p className="text-sm text-green-700 mt-1">Reducen el caudal de agua hasta un 50% sin perder presión, mezclando aire con el agua.</p>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="flex items-start p-4 rounded-md bg-green-50"
              >
                <div className="mr-4 flex-shrink-0">
                  <div className="w-16 h-16 rounded-md bg-white p-2 flex items-center justify-center shadow-sm">
                    <img  alt="Cabezal de ducha eficiente" className="w-full h-full object-contain" src="https://images.unsplash.com/photo-1697652973443-85568b39de07" />
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-green-800">Duchas de Bajo Flujo</h4>
                  <p className="text-sm text-green-700 mt-1">Limitan el flujo de agua a 6-8 litros por minuto, en comparación con los 15-20 litros de las duchas convencionales.</p>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="flex items-start p-4 rounded-md bg-green-50"
              >
                <div className="mr-4 flex-shrink-0">
                  <div className="w-16 h-16 rounded-md bg-white p-2 flex items-center justify-center shadow-sm">
                    <img  alt="Sistema de riego inteligente" className="w-full h-full object-contain" src="https://images.unsplash.com/photo-1688791388604-018e38e39bfa" />
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-green-800">Sistemas de Riego Inteligentes</h4>
                  <p className="text-sm text-green-700 mt-1">Utilizan sensores de humedad y datos meteorológicos para optimizar el riego de jardines y plantas.</p>
                </div>
              </motion.div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-lg mb-8">
        <CardHeader>
          <CardTitle>Impacto Ambiental</CardTitle>
          <CardDescription>Por qué es importante ahorrar agua</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="p-4 rounded-md bg-blue-50 border border-blue-100 text-center"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-blue-100 flex items-center justify-center">
                <DropletIcon size={32} className="text-blue-500" />
              </div>
              <h4 className="font-medium text-blue-800 mb-2">Conservación de Recursos</h4>
              <p className="text-sm text-blue-700">El agua dulce representa solo el 2.5% del agua total del planeta, y solo el 0.3% está disponible para consumo humano.</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="p-4 rounded-md bg-green-50 border border-green-100 text-center"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
                <img  alt="Ecosistema acuático" className="w-10 h-10 object-contain" src="https://images.unsplash.com/photo-1605027538720-37afa8b9fc39" />
              </div>
              <h4 className="font-medium text-green-800 mb-2">Protección de Ecosistemas</h4>
              <p className="text-sm text-green-700">El uso excesivo de agua afecta a ríos, lagos y humedales, poniendo en peligro la biodiversidad acuática.</p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="p-4 rounded-md bg-amber-50 border border-amber-100 text-center"
            >
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-amber-100 flex items-center justify-center">
                <img  alt="Ahorro energético" className="w-10 h-10 object-contain" src="https://images.unsplash.com/photo-1615222597833-52ae19caa619" />
              </div>
              <h4 className="font-medium text-amber-800 mb-2">Ahorro Energético</h4>
              <p className="text-sm text-amber-700">El tratamiento y distribución del agua requiere energía. Al ahorrar agua, también reduces tu huella de carbono.</p>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-lg water-wave">
        <CardHeader>
          <CardTitle>Proyecto AguaConsciente</CardTitle>
          <CardDescription>Sobre nuestra iniciativa</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 gradient-text">Nuestra Misión</h3>
              <p className="text-gray-700 mb-4">
                El proyecto AguaConsciente nace con el objetivo de crear conciencia sobre el consumo responsable del agua y proporcionar herramientas tecnológicas que ayuden a las personas a monitorear y reducir su consumo.
              </p>
              <p className="text-gray-700 mb-4">
                Mediante sensores inteligentes, análisis de datos y alertas en tiempo real, buscamos detectar patrones de consumo excesivo y posibles fugas, permitiendo a los usuarios tomar medidas inmediatas para corregir problemas y adoptar hábitos más sostenibles.
              </p>
              <div className="p-4 bg-blue-50 rounded-md border border-blue-100 mt-6">
                <h4 className="font-medium text-blue-800 mb-2">Objetivos del Proyecto</h4>
                <ul className="space-y-2 text-sm text-blue-700">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Reducir el consumo de agua en hogares en un 20%</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Detectar y prevenir fugas de agua en tiempo real</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Educar sobre la importancia del uso responsable del agua</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Crear una comunidad comprometida con la sostenibilidad</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div>
              <div className="rounded-lg overflow-hidden shadow-lg mb-6">
                <img  alt="Proyecto AguaConsciente" className="w-full h-64 object-cover" src="https://images.unsplash.com/photo-1553531768-d2a5f2c7ca2a" />
              </div>
              
              <h3 className="text-xl font-bold mb-4 gradient-text">Tecnología Utilizada</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-white rounded-md border border-gray-200 shadow-sm">
                  <h4 className="font-medium mb-2">Sensores IoT</h4>
                  <p className="text-sm text-gray-600">Dispositivos de alta precisión que miden el flujo de agua en tiempo real.</p>
                </div>
                
                <div className="p-4 bg-white rounded-md border border-gray-200 shadow-sm">
                  <h4 className="font-medium mb-2">Análisis de Datos</h4>
                  <p className="text-sm text-gray-600">Algoritmos que detectan patrones anormales de consumo.</p>
                </div>
                
                <div className="p-4 bg-white rounded-md border border-gray-200 shadow-sm">
                  <h4 className="font-medium mb-2">Alertas Inteligentes</h4>
                  <p className="text-sm text-gray-600">Notificaciones en tiempo real sobre consumo excesivo o fugas.</p>
                </div>
                
                <div className="p-4 bg-white rounded-md border border-gray-200 shadow-sm">
                  <h4 className="font-medium mb-2">Plataforma Web</h4>
                  <p className="text-sm text-gray-600">Interfaz intuitiva para visualizar y analizar tu consumo de agua.</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TipsTab;
