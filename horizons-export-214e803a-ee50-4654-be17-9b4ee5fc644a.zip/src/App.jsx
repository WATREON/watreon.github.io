
import React, { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/components/ui/use-toast";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import DashboardTab from "@/components/DashboardTab";
import StatisticsTab from "@/components/StatisticsTab";
import AlertsTab from "@/components/AlertsTab";
import TipsTab from "@/components/TipsTab";
import { initialData } from "@/data/initialData";

const App = () => {
  const [data, setData] = useState(() => {
    const savedData = localStorage.getItem("waterConsumptionData");
    return savedData ? JSON.parse(savedData) : initialData;
  });
  const [activeTab, setActiveTab] = useState("dashboard");
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    localStorage.setItem("waterConsumptionData", JSON.stringify(data));
  }, [data]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setProgress(data.currentUsage / data.dailyGoal * 100);
    }, 500);
    return () => clearTimeout(timer);
  }, [data.currentUsage, data.dailyGoal]);

  const resolveAlert = (id) => {
    const updatedAlerts = data.alerts.map(alert => 
      alert.id === id ? { ...alert, status: "resolved" } : alert
    );
    
    setData({ ...data, alerts: updatedAlerts });
    
    toast({
      title: "Alerta resuelta",
      description: "La alerta ha sido marcada como resuelta.",
      duration: 3000,
    });
  };

  const addRandomUsage = () => {
    const randomUsage = Math.floor(Math.random() * 50) + 100;
    const today = new Date().toLocaleDateString('es-ES', { weekday: 'long' });
    
    const capitalizedToday = today.charAt(0).toUpperCase() + today.slice(1);
    
    const updatedDailyUsage = [...data.dailyUsage];
    const todayIndex = updatedDailyUsage.findIndex(item => item.day === capitalizedToday);
    
    if (todayIndex !== -1) {
      updatedDailyUsage[todayIndex].usage = randomUsage;
    }
    
    setData({
      ...data,
      currentUsage: randomUsage,
      dailyUsage: updatedDailyUsage
    });
    
    toast({
      title: "Datos actualizados",
      description: `Consumo actual: ${randomUsage} litros`,
      duration: 3000,
    });
  };

  const updateGoal = (newGoal) => {
    setData({
      ...data,
      dailyGoal: newGoal
    });
    
    toast({
      title: "Meta actualizada",
      description: `Nueva meta diaria: ${newGoal} litros`,
      duration: 3000,
    });
  };

  const renderActiveTab = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardTab data={data} progress={progress} resolveAlert={resolveAlert} addRandomUsage={addRandomUsage} updateGoal={updateGoal} setActiveTab={setActiveTab} />;
      case "statistics":
        return <StatisticsTab data={data} />;
      case "alerts":
        return <AlertsTab data={data} resolveAlert={resolveAlert} />;
      case "tips":
        return <TipsTab data={data} />;
      default:
        return <DashboardTab data={data} progress={progress} resolveAlert={resolveAlert} addRandomUsage={addRandomUsage} updateGoal={updateGoal} setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="container mx-auto px-4 py-8 flex-grow">
        {renderActiveTab()}
      </main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default App;
