
import React from "react";
export const initialData = {
  dailyUsage: [
    { day: "Lunes", usage: 120 },
    { day: "Martes", usage: 150 },
    { day: "Miércoles", usage: 180 },
    { day: "Jueves", usage: 220 },
    { day: "Viernes", usage: 190 },
    { day: "Sábado", usage: 130 },
    { day: "Domingo", usage: 100 }
  ],
  monthlyUsage: [
    { month: "Enero", usage: 3200 },
    { month: "Febrero", usage: 2900 },
    { month: "Marzo", usage: 3100 },
    { month: "Abril", usage: 3400 },
    { month: "Mayo", usage: 3600 },
    { month: "Junio", usage: 3800 }
  ],
  alerts: [
    { id: 1, type: "Exceso", message: "Consumo excesivo detectado el 15/05/2025", status: "active" },
    { id: 2, type: "Fuga", message: "Posible fuga detectada en baño principal", status: "active" },
    { id: 3, type: "Recordatorio", message: "Revisar sistema de riego", status: "resolved" }
  ],
  tips: [
    "Cierra el grifo mientras te cepillas los dientes para ahorrar hasta 12 litros por minuto.",
    "Instala aireadores en los grifos para reducir el consumo hasta un 50%.",
    "Repara las fugas: un grifo que gotea puede desperdiciar más de 11,000 litros al año.",
    "Utiliza la lavadora y el lavavajillas solo cuando estén llenos.",
    "Recoge agua de lluvia para regar las plantas."
  ],
  currentUsage: 165,
  dailyGoal: 150,
  monthlyUsageTotal: 3800,
  monthlyGoal: 4500,
  savingsPercentage: 15
};
